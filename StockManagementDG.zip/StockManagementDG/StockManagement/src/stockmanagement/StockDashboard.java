/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stockmanagement;

/**
 *
 * @author Gabriel
 */import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import stockmanagement.StockData;

public class StockDashboard {

    public static void updateDashboard(String stockName, int quantity, long purchaseDate, double totalCost, double currentValue, double gainLoss, double percentage) {
        System.out.println("Stock: " + stockName);
        System.out.println("Cantidad: " + quantity);
        System.out.println("Fecha de compra: " + new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(purchaseDate * 1000)));
        System.out.println("Costo total: " + String.format("%.2f", totalCost));
        System.out.println("Valor actual: " + String.format("%.2f", currentValue));
        System.out.println("Ganancia/Pérdida: " + String.format("%.2f", gainLoss));
        System.out.println("Porcentaje: " + percentage + "%");
    }

    public static StockData fetchStockData(String stockName, String purchaseDate) throws Exception {
        String apiKey = "HRGK40MNW83SFPS4"; // Reemplaza con tu clave de API de Alpha Vantage
        String urlString = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=" + stockName + "&apikey=" + apiKey + "&outputsize=full&datatype=csv";
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine).append("\n");
        }
        in.close();
        conn.disconnect();

        String[] rows = content.toString().split("\n");
        Double purchasePrice = null;
        Double currentPrice = null;

        for (String row : rows) {
            String[] columns = row.split(",");
            String date = columns[0];
            Double close = Double.parseDouble(columns[4]);

            if (date.equals(purchaseDate)) {
                purchasePrice = close;
            }
            if (new SimpleDateFormat("yyyy-MM-dd").parse(date).before(new Date()) && currentPrice == null) {
                currentPrice = close;
            }

            if (purchasePrice != null && currentPrice != null) {
                break;
            }
        }

        return new StockData(purchasePrice, currentPrice);
    }

    public static StockValue calculateStockValues(double purchasePrice, double currentPrice, int quantity) {
        double totalCost = purchasePrice * quantity;
        double currentValue = currentPrice * quantity;
        double gainLoss = currentValue - totalCost;
        double percentage = (gainLoss / totalCost) * 100;

        return new StockValue(totalCost, currentValue, gainLoss, percentage);
    }
    
   

}

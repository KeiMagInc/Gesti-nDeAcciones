/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stockmanagement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import stockmanagement.StockData;
/**
 *
 * @author Anthony
 */
public class StockManagement {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Clave API de Alpha Vantage (reemplaza con tu clave)
        String apiKey = "FN4LBIK1RVRI8TPH";  // Reemplaza con tu clave API de Alpha Vantage

        // Crear una instancia de AlphaVantageAPI
        AlphaVantageAPI api = new AlphaVantageAPI(apiKey);

        // Símbolo de acción a consultar (puedes cambiarlo por el que desees)
        String symbol = "AAPL";  // Ejemplo: AAPL (Apple)
        
        // Precio histórico de la acción para una fecha específica
        String fecha = "2024-11-29";
        double precioHistorico = api.obtenerPrecioHistorico(symbol, fecha);
        
        // Precio actual de la acción
        double precioActual = api.obtenerPrecioActual(symbol);
        
        // Verificar que los precios se obtuvieron correctamente
        if (precioActual == -1 || precioHistorico == -1) {
            System.out.println("Hubo un error al obtener los precios.");
            return;
        }

        // Crear el objeto StockData con los precios obtenidos
        StockData stockData = new StockData(precioHistorico, precioActual);

        // Cálculo de valores relacionados con las acciones
        int cantidad = 10;  // Cantidad de acciones
        double totalCost = stockData.getPurchasePrice() * cantidad;
        double currentValue = stockData.getCurrentPrice() * cantidad;
        double gainLoss = currentValue - totalCost;
        double percentage = (gainLoss / totalCost) * 100;

        // Crear el objeto StockValue con los resultados calculados
        StockValue stockValues = new StockValue(totalCost, currentValue, gainLoss, percentage);

        // Actualización del dashboard con los datos calculados
        StockDashboard.updateDashboard(
            symbol,
            cantidad, 
            1701302400L, // Fecha de compra (en formato Unix)
            stockValues.getTotalCost(),
            stockValues.getCurrentValue(),
            stockValues.getGainLoss(),
            stockValues.getPercentage()
        );
    }
    
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stockmanagement;

/**
 *
 * @author Gabriel
 */
public class StockValue {
    private double totalCost;
    private double currentValue;
    private double gainLoss;
    private double percentage;

    // Constructor
    public StockValue(double totalCost, double currentValue, double gainLoss, double percentage) {
        this.totalCost = totalCost;
        this.currentValue = currentValue;
        this.gainLoss = gainLoss;
        this.percentage = percentage;
    }

    // Getters
    public double getTotalCost() {
        return totalCost;
    }

    public double getCurrentValue() {
        return currentValue;
    }

    public double getGainLoss() {
        return gainLoss;
    }

    public double getPercentage() {
        return percentage;
    }

    // Setters
    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public void setCurrentValue(double currentValue) {
        this.currentValue = currentValue;
    }

    public void setGainLoss(double gainLoss) {
        this.gainLoss = gainLoss;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}
